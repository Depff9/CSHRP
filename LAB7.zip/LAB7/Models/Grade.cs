﻿namespace SchoolGradesAPI.Models
{
    public class Grade
    {
        public string Subject { get; set; }
        public int Score { get; set; }
    }
}